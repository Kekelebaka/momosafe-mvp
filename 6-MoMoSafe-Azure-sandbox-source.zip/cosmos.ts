import {CosmosClient,type Container} from '@azure/cosmos';import type {Escrow} from './model.js';import type {Store} from './store.js';
// One container, /escrowId partition, to atomically commit state AND immutable events.
// Two containers cannot provide that atomic transaction. Do not provision from this file.
export class CosmosStore implements Store{
 constructor(private container:Container){}
 static fromConnection(connection:string,database:string,container:string){return new CosmosStore(new CosmosClient(connection).database(database).container(container));}
 async getUserPolicy(id:string){try{const{resource}=await this.container.item('policy',id).read();return resource as {status:string}|undefined;}catch(e:any){if(e.code===404)return undefined;throw e;}}
 async setUserPolicy(id:string,status:string,reason:string,actor:string){const event={id:crypto.randomUUID(),escrowId:id,type:'USER_POLICY_CHANGED',status,reason,actor,at:new Date().toISOString()};const result=await this.container.items.batch([{operationType:'Upsert',resourceBody:{id:'policy',escrowId:id,status}},{operationType:'Create',resourceBody:event}],id);if(!result.code||result.code>=300)throw new Error('CONFLICT');}
 async get(id:string){try{const {resource}=await this.container.item('state',id).read();return resource?.escrow as Escrow|undefined;}catch(e:any){if(e.code===404)return undefined;throw e;}}
 async list(){const {resources}=await this.container.items.query({query:'SELECT c.escrow FROM c WHERE c.id = @id',parameters:[{name:'@id',value:'state'}]}).fetchAll();return resources.map(r=>r.escrow as Escrow);}
 async save(e:Escrow,expected:number){let etag:string|undefined;let priorEvents=0;if(expected){const {resource}=await this.container.item('state',e.id).read();if(resource?.escrow.version!==expected)throw new Error('CONFLICT');etag=resource._etag;priorEvents=resource.escrow.ledger.length;}
 const state={id:'state',escrowId:e.id,escrow:e};const operations:any[]=[expected?{operationType:'Replace',id:'state',resourceBody:state,ifMatch:etag}:{operationType:'Create',resourceBody:state},...e.ledger.slice(priorEvents).map(event=>({operationType:'Create',resourceBody:{id:event.id,escrowId:e.id,type:'ledger',event}}))];
 const result=await this.container.items.batch(operations,e.id);if(!result.code||result.code>=300)throw new Error('CONFLICT');}
}
