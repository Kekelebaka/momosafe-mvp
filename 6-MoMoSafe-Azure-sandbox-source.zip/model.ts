import {z} from 'zod';
export type State='DRAFT'|'AWAITING_PAYMENT'|'LOCKED'|'DISPUTED'|'RELEASED'|'REFUNDED'|'EXPIRED';
export type Kind='COLLECTION'|'RELEASE'|'REFUND';
export type PaymentStatus='PENDING'|'SUCCESSFUL'|'FAILED';
export type Session={id:string;role:'buyer'|'seller'|'admin';adminId?:string;demoOwner?:string};
export type Op={ref:string;kind:Kind;status:PaymentStatus;attempts:number;error?:string};
export type Entry={id:string;seq:number;type:string;actor:string;at:string;deltaCents:number;reference?:string};
export type Escrow={demoOwner?:string;id:string;state:State;item:string;note:string;amountCents:number;currency:'ZAR'|'GHS';seller:string;buyer:string;handoverClaim?:{reason:string;at:string;actor:string};createdAt:string;paymentDeadline?:string;handoverDeadline?:string;version:number;ops:Op[];ledger:Entry[];dispute?:{reason:string;approvals:{adminId:string;decision:'RELEASE'|'REFUND'}[]};qr?:{hash:string;expiresAt:number;used:boolean};requests:Record<string,string>};
export const createSchema=z.object({item:z.string().trim().min(3).max(100),note:z.string().trim().max(240).default(''),currency:z.enum(['ZAR','GHS']).default('ZAR'),buyer:z.string().min(3).max(200).optional(),amount:z.string().regex(/^(?:0|[1-9]\d{0,3})\.\d{2}$/)}).strict();
export function cents(amount:string){const [major,minor]=amount.split('.'); const n=Number(major)*100+Number(minor);if(!Number.isSafeInteger(n)||n<=0||n>100000)throw new Fault(400,'INVALID_AMOUNT','Use 0.01 to 1,000.00 in this mock.');return n;}
export const money=(n:number)=>(n/100).toFixed(2);
export class Fault extends Error{constructor(public status:number,public code:string,message:string){super(message);}}
export function requireThat(ok:unknown,status:number,code:string,message:string):asserts ok{if(!ok)throw new Fault(status,code,message);}
export const terminal=(s:State)=>['RELEASED','REFUNDED','EXPIRED'].includes(s);
