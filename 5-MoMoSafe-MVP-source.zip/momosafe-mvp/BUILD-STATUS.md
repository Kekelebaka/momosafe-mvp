# Build status

Local mock application: implemented and locally tested.
Azure deployment: not started, awaiting subscription and cost authority.
MTN sandbox: not connected, awaiting registration authority and keys.
Real money: disabled, out of scope.
Cloud adapter runtime validation: outstanding.

The repo distribution is a source archive plus extraction instructions. Extract before running. No credentials or local test data are included.
