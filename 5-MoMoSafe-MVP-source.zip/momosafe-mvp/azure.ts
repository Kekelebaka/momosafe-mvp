import {app} from '@azure/functions';import * as df from 'durable-functions';
import {Engine} from './engine.js';import {CosmosStore} from './cosmos.js';import {MockMoMo} from './momo.js';
// Compile-tested scaffold only. Native MoMo, cloud identity and HTTP commands are NOT wired.
// Deliberately refuses to boot in real-money mode.
if(process.env.MOMO_MODE&&process.env.MOMO_MODE!=='mock')throw new Error('Real money is disabled.');
let instance:Engine|undefined;
function engine(){if(!instance){if(!process.env.COSMOS_CONNECTION)throw new Error('No Cosmos configuration. Azure has not been provisioned.');instance=new Engine(CosmosStore.fromConnection(process.env.COSMOS_CONNECTION,'momosafe','escrowData'),new MockMoMo());}return instance;}
df.app.activity('reconcileEscrowV1',{handler:async(id:string)=>{await engine().reconcile(id);const e=await engine().store.get(id);return e?{state:e.state,deadline:e.handoverDeadline??e.paymentDeadline}:null;}});
df.app.orchestration('escrowOrchestratorV1',function*(ctx){const {escrowId}=ctx.df.getInput() as {escrowId:string};while(true){const snapshot:{state:string;deadline?:string}|null=yield ctx.df.callActivityWithRetry('reconcileEscrowV1',new df.RetryOptions(5000,3),escrowId);if(!snapshot||['RELEASED','REFUNDED','EXPIRED'].includes(snapshot.state))return snapshot;
 const now=ctx.df.currentUtcDateTime.getTime();const next=snapshot.deadline?Math.max(now+1000,Math.min(now+300_000,Date.parse(snapshot.deadline))):now+300_000;
 const timer=ctx.df.createTimer(new Date(next));const changed=ctx.df.waitForExternalEvent('changed');const winner=yield ctx.df.Task.any([timer,changed]);if(winner===changed)timer.cancel();
 // Periodically checkpoint history without changing the instance ID.
 // Continue-as-new bounds history; periodic reads recover a missed doorbell.
 ctx.df.continueAsNew({escrowId});return;
}});
app.timer('reconcilerV1',{schedule:'0 */5 * * * *',handler:async()=>{await engine().reconcile();}});
app.http('health',{methods:['GET'],authLevel:'anonymous',route:'health',handler:async()=>({jsonBody:{mode:'mock-scaffold',livePayments:false,cloudHttpCommands:false}})});
