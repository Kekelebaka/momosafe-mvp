import type{Escrow,Kind,PaymentStatus}from'./model.js';import type{Rail}from'./momo.js';
export type ProductCredentials={subscriptionKey:string;apiUser:string;apiKey:string};
export type SandboxConfig={baseUrl:'https://sandbox.momodeveloper.mtn.com';collection:ProductCredentials;disbursement:ProductCredentials;payer:string;payee:string};
// Sandbox only. Never derive a test payment's currency by relabelling ZAR/GHS.
// Numeric amounts are EUR canned test data, not a conversion or live holding balance.
export class SandboxRail implements Rail{
 private tokens=new Map<string,{value:string;expires:number}>();
 constructor(private config:SandboxConfig,private http:typeof fetch=fetch,private now=()=>Date.now()){if(config.baseUrl!=='https://sandbox.momodeveloper.mtn.com')throw new Error('Only the verified MTN sandbox host is allowed.');}
 private product(kind:Kind){return kind==='COLLECTION'?'collection':'disbursement';}
 private async token(product:'collection'|'disbursement'){
  const cached=this.tokens.get(product);if(cached&&cached.expires>this.now())return cached.value;
  const c=this.config[product];const res=await this.http(this.config.baseUrl+'/'+product+'/token/',{method:'POST',headers:{Authorization:'Basic '+Buffer.from(c.apiUser+':'+c.apiKey).toString('base64'),'Ocp-Apim-Subscription-Key':c.subscriptionKey},signal:AbortSignal.timeout(10000)});
  if(!res.ok)throw new Error('MTN sandbox token unavailable ('+res.status+').');const data=await res.json() as any;if(typeof data.access_token!=='string'||!Number.isFinite(Number(data.expires_in)))throw new Error('Invalid MTN token response.');this.tokens.set(product,{value:data.access_token,expires:this.now()+Math.max(0,Number(data.expires_in)-60)*1000});return data.access_token;
 }
 private async request(product:'collection'|'disbursement',path:string,method:string,ref:string,body?:unknown){
  const c=this.config[product];const call=async()=>this.http(this.config.baseUrl+'/'+product+path,{method,headers:{Authorization:'Bearer '+await this.token(product),'Ocp-Apim-Subscription-Key':c.subscriptionKey,'X-Target-Environment':'sandbox','Content-Type':'application/json',...(method==='POST'?{'X-Reference-Id':ref}:{})},...(body?{body:JSON.stringify(body)}:{}),signal:AbortSignal.timeout(10000)});
  let res=await call();if(res.status===401){this.tokens.delete(product);res=await call();}return res;
 }
 async submit(ref:string,kind:Kind,amountCents:number,escrow?:Escrow){
  if(!Number.isSafeInteger(amountCents)||amountCents<=0)throw new Error('Invalid test amount.');
  const product=this.product(kind),collection=kind==='COLLECTION';const party=kind==='RELEASE'?this.config.payee:this.config.payer;
  if(!/^\d{8,15}$/.test(party))throw new Error('Configure a documented sandbox test MSISDN.');
  const body={amount:(amountCents/100).toFixed(2),currency:'EUR',externalId:escrow?.id??ref,...(collection?{payer:{partyIdType:'MSISDN',partyId:party},payerMessage:'MoMoSafe EUR test only',payeeNote:'No real money'}:{payee:{partyIdType:'MSISDN',partyId:party},payerMessage:'MoMoSafe EUR test only',payeeNote:'No real money'})};
  const res=await this.request(product,collection?'/v1_0/requesttopay':'/v1_0/transfer','POST',ref,body);
  if(res.status!==202&&res.status!==409)throw new Error('MTN sandbox submission uncertain ('+res.status+'). Reconcile the same reference.');
 }
 async status(ref:string,kind:Kind='COLLECTION'):Promise<PaymentStatus>{const product=this.product(kind);const res=await this.request(product,(kind==='COLLECTION'?'/v1_0/requesttopay/':'/v1_0/transfer/')+encodeURIComponent(ref),'GET',ref);if(!res.ok)throw new Error('MTN sandbox status unavailable ('+res.status+').');const data=await res.json() as any;return data.status==='SUCCESSFUL'?'SUCCESSFUL':data.status==='FAILED'?'FAILED':'PENDING';}
}
