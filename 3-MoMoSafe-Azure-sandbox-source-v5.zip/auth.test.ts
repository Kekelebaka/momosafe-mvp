import{describe,it,expect}from'vitest';import{issueSession,verifySession,roleSession}from'./auth';
const identity={id:'google:123',email:'seller@example.test',name:'Test'};const secret='not-a-production-secret-test-only-123456789';
describe('authenticated sessions',()=>{
 it('verifies signed, issuer-bound sessions',async()=>{const token=await issueSession(identity,secret);expect((await verifySession(token,secret)).id).toBe(identity.id);});
 it('rejects tampering and another signing key',async()=>{const token=await issueSession(identity,secret);await expect(verifySession(token+'x',secret)).rejects.toThrow('Sign in');await expect(verifySession(token,secret+'x')).rejects.toThrow('Sign in');});
 it('rejects missing strong server secret',async()=>{await expect(issueSession(identity,'')).rejects.toThrow('not configured');});
 it('never grants admin from a role or adminId claim',()=>{expect(()=>roleSession(identity,'admin',[])).toThrow('not granted');expect(roleSession(identity,'buyer',[]).adminId).toBeUndefined();});
 it('binds operator approvals to a verified Google subject',()=>{expect(roleSession(identity,'admin',[identity.email]).adminId).toBe(identity.id);});
});
