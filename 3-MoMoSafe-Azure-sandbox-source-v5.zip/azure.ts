import {app} from '@azure/functions';import * as df from 'durable-functions';
import {Engine} from './engine.js';import {CosmosStore} from './cosmos.js';
import {SandboxRail} from './sandbox-rail.js';import{registerHttp}from'./cloud-http.js';
if(process.env.MOMO_MODE&&process.env.MOMO_MODE!=='sandbox')throw new Error('Live money and mock cloud deployments are disabled.');
let instance:Engine|undefined;let storage:CosmosStore|undefined;
function store(){if(!storage){if(!process.env.COSMOS_CONNECTION)throw new Error('No Cosmos configuration.');storage=CosmosStore.fromConnection(process.env.COSMOS_CONNECTION,'momosafe','escrowData');}return storage;}
function credential(prefix:string){return{subscriptionKey:process.env[prefix+'_SUBSCRIPTION_KEY']??'',apiUser:process.env[prefix+'_API_USER']??'',apiKey:process.env[prefix+'_API_KEY']??''};}
function engine(){if(!instance){if(process.env.MOMO_MODE!=='sandbox')throw new Error('MTN sandbox not configured.');instance=new Engine(store(),new SandboxRail({baseUrl:'https://sandbox.momodeveloper.mtn.com',collection:credential('MTN_COLLECTION'),disbursement:credential('MTN_DISBURSEMENT'),payer:process.env.MTN_TEST_PAYER??'',payee:process.env.MTN_TEST_PAYEE??''}));}return instance;}
registerHttp(engine,store);
df.app.activity('reconcileEscrowV1',{handler:async(id:string)=>{await engine().reconcile(id);const e=await engine().store.get(id);return e?{state:e.state,deadline:e.handoverDeadline??e.paymentDeadline}:null;}});
df.app.orchestration('escrowOrchestratorV1',function*(ctx){const {escrowId}=ctx.df.getInput() as {escrowId:string};while(true){const snapshot:{state:string;deadline?:string}|null=yield ctx.df.callActivityWithRetry('reconcileEscrowV1',new df.RetryOptions(5000,3),escrowId);if(!snapshot||['RELEASED','REFUNDED','EXPIRED'].includes(snapshot.state))return snapshot;
 const now=ctx.df.currentUtcDateTime.getTime();const deadline=snapshot.deadline?Date.parse(snapshot.deadline):0;const next=deadline>now?Math.min(now+300_000,deadline):now+300_000;
 const timer=ctx.df.createTimer(new Date(next));const changed=ctx.df.waitForExternalEvent('changed');const winner=yield ctx.df.Task.any([timer,changed]);if(winner===changed)timer.cancel();
 // Periodically checkpoint history without changing the instance ID.
 // Continue-as-new bounds history; periodic reads recover a missed doorbell.
 ctx.df.continueAsNew({escrowId});return;
}});
app.timer('reconcilerV1',{schedule:'0 */5 * * * *',handler:async()=>{await engine().reconcile();}});
app.http('health',{methods:['GET'],authLevel:'anonymous',route:'health',handler:async()=>({jsonBody:{mode:'sandbox',livePayments:false,railCurrency:'EUR',configured:!!process.env.GOOGLE_CLIENT_ID&&!!process.env.COSMOS_CONNECTION}})});
