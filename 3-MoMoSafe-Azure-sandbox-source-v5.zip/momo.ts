import type {Kind,PaymentStatus,Escrow} from './model.js';
export interface Rail {submit(ref:string,kind:Kind,amountCents:number,escrow?:Escrow):Promise<void>;status(ref:string,kind?:Kind):Promise<PaymentStatus>}
// Intentionally no HTTP transport. No keys, wallet numbers or real money are accepted.
export class MockMoMo implements Rail{
 private states=new Map<string,PaymentStatus>();
 submissions=new Map<string,number>();
 async submit(ref:string,_kind:Kind,_amount:number){this.submissions.set(ref,(this.submissions.get(ref)??0)+1);if(!this.states.has(ref))this.states.set(ref,'PENDING');}
 async status(ref:string){return this.states.get(ref)??'PENDING';}
 settle(ref:string,status:PaymentStatus){this.states.set(ref,status);}
}
