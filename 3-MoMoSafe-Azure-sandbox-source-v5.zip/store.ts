import {mkdir,readFile,writeFile,rename} from 'node:fs/promises';
import {dirname} from 'node:path';
import type {Escrow} from './model.js';
export interface Store {get(id:string):Promise<Escrow|undefined>;list():Promise<Escrow[]>;save(e:Escrow,expected:number):Promise<void>}
export class MemoryStore implements Store{
 protected rows=new Map<string,Escrow>();
 async get(id:string){const e=this.rows.get(id);return e?structuredClone(e):undefined;}
 async list(){return structuredClone([...this.rows.values()]);}
 async save(e:Escrow,expected:number){if((this.rows.get(e.id)?.version??0)!==expected)throw new Error('CONFLICT');this.rows.set(e.id,structuredClone(e));}
}
// A single process serialises commands. Atomic rename prevents half-written local JSON.
// This is a local demo store, not a distributed database.
export class JsonStore extends MemoryStore{
 constructor(private path:string){super();}
 async init(){try{const rows=JSON.parse(await readFile(this.path,'utf8')) as Escrow[];this.rows=new Map(rows.map(e=>[e.id,e]));}catch(e:any){if(e.code!=='ENOENT')throw e;}return this;}
 override async save(e:Escrow,expected:number){await super.save(e,expected);await mkdir(dirname(this.path),{recursive:true});await writeFile(this.path+'.tmp',JSON.stringify([...this.rows.values()]),{mode:0o600});await rename(this.path+'.tmp',this.path);}
}
