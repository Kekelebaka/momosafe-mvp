import {describe,it,expect,vi} from 'vitest';import{prepareInvite,submitInvite,PROPOSED_SENDER,INVITE_TEMPLATE_VERSION}from'./invite.js';import type{Escrow}from'./model.js';
const e:Escrow={id:'MMS-TEST',state:'DRAFT',item:'EUR TEST phone',note:'',amountCents:100000,currency:'GHS',seller:'seller',buyer:'buyer',createdAt:new Date().toISOString(),version:1,ops:[],ledger:[],requests:{}};
const now=new Date('2026-11-02T16:00:00Z');const job=()=>prepareInvite(e,'test@example.invalid',now);const cfg={enabled:true,apiKey:'re_fake_test_only',approvedSender:PROPOSED_SENDER,approvedTemplate:INVITE_TEMPLATE_VERSION,approvedRecipients:['test@example.invalid']};
describe('disabled invite preparation',()=>{
 it('stable key and sandbox wording without token',()=>{expect(job().id).toBe(job().id);expect(job().payload.text).toContain('EUR test data');expect(job().payload.text).toContain('GHS 1000.00');expect(job().payload.from).toBe(PROPOSED_SENDER);expect(job().payload).not.toHaveProperty('reply_to');});
 it('rejects guided demo',()=>expect(()=>prepareInvite({...e,demoOwner:'owner'},'test@example.invalid')).toThrow());
 it('rejects header injection',()=>expect(()=>prepareInvite(e,'a@example.com\r\nBcc:b@example.com')).toThrow());
 it('rejects non-draft',()=>expect(()=>prepareInvite({...e,state:'LOCKED'},'a@example.com')).toThrow());
 it('disabled never makes network request',async()=>{const f=vi.fn();await expect(submitInvite(job(),{...cfg,enabled:false},f as any,now.getTime())).rejects.toMatchObject({code:'INVITE_DISABLED'});expect(f).not.toHaveBeenCalled();});
 it('requires approved exact sender/template',async()=>{await expect(submitInvite(job(),{...cfg,approvedSender:''},vi.fn() as any,now.getTime())).rejects.toMatchObject({code:'INVITE_APPROVAL'});});
 it('requires recipient scope',async()=>{await expect(submitInvite(job(),{...cfg,approvedRecipients:[]},vi.fn() as any,now.getTime())).rejects.toMatchObject({code:'INVITE_SCOPE'});});
 it('refuses ambiguous retries outside dedupe window',async()=>{await expect(submitInvite(job(),cfg,vi.fn() as any,now.getTime()+24*3600_000)).rejects.toMatchObject({code:'INVITE_REVIEW'});});
 it('uses fixed endpoint and stable provider dedupe header',async()=>{const f=vi.fn().mockResolvedValue({ok:true,json:async()=>({id:'provider-test'})});const sent=await submitInvite(job(),cfg,f as any,now.getTime());expect(sent.status).toBe('SENT');expect(sent.providerId).toBe('provider-test');expect(f.mock.calls[0][0]).toBe('https://api.resend.com/emails');expect(f.mock.calls[0][1].headers['Idempotency-Key']).toBe(job().id);});
 it('provider error does not mark sent',async()=>{const f=vi.fn().mockResolvedValue({ok:false,status:429});await expect(submitInvite(job(),cfg,f as any,now.getTime())).rejects.toMatchObject({code:'INVITE_PROVIDER'});expect(job().status).toBe('PREPARED');});
});
