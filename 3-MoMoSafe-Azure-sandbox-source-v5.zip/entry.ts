if(import.meta.env.VITE_PREVIEW_MODE==='device')void import('./web');else void import('./cloud-web');
