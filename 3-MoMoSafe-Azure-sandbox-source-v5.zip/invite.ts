import {createHash} from 'node:crypto';
import {Fault,requireThat,type Escrow} from './model.js';
export const INVITE_TEMPLATE_VERSION='sandbox-invite-v1';
export const PROPOSED_SENDER='MoMoSafe Sandbox <momosafe-notifications@ubuntutown.co.za>';
const ORIGIN='https://momosafe-053-sandbox.azurewebsites.net/';
export type InviteMessage={from:string;to:string[];subject:string;text:string};
export type InviteJob={id:string;escrowId:string;recipient:string;payload:InviteMessage;createdAt:string;status:'PREPARED'|'SENT'|'REVIEW';providerId?:string};
const validEmail=(v:string)=>v.length<=254&&/^[^@\s<>\r\n]+@[^@\s<>\r\n]+\.[^@\s<>\r\n]+$/.test(v);
export function prepareInvite(e:Escrow,recipient:string,now=new Date()):InviteJob{
 requireThat(!e.demoOwner,403,'DEMO_INVITE','Guided demo never sends invitations.');
 requireThat(e.state==='DRAFT',409,'INVITE_STATE','Only a new draft can be invited.');
 requireThat(validEmail(recipient),400,'INVITE_RECIPIENT','Valid buyer email required.');
 const email=recipient.toLowerCase();
 const item=e.item.replace(/[\r\n]+/g,' ').slice(0,100);
 const text=`You have been invited to review a MoMoSafe sandbox deal.\n\nItem: ${item}\nAmount: ${e.currency} ${(e.amountCents/100).toFixed(2)}\nDeal reference: ${e.id}\n\nOpen ${ORIGIN} and sign in with the Google email address that received this invitation. Select Buyer, then My deals to review it.\n\nThis is a test invitation. No real money is collected or held. MTN sandbox transactions use EUR test data; the displayed ZAR or GHS amount is not a real balance or a currency conversion. Only accept if you expected this test deal.\n\nIf you were not expecting this invitation, ignore it. Do not share handover codes or passwords.\n\nMoMoSafe Sandbox`;
 const id='invite-'+createHash('sha256').update(e.id+'|'+email+'|'+INVITE_TEMPLATE_VERSION).digest('hex');
 return{id,escrowId:e.id,recipient:email,payload:{from:PROPOSED_SENDER,to:[email],subject:'MoMoSafe sandbox deal invitation: '+e.id,text},createdAt:now.toISOString(),status:'PREPARED'};
}
export type InviteConfig={enabled:boolean;apiKey:string;approvedSender?:string;approvedTemplate?:string;approvedRecipients:string[]};
// Not registered as an HTTP route or worker. Disabled until sender, wording and send scope are approved.
// Persist the immutable job before calling this. Commit providerId+SENT using Cosmos CAS afterwards.
export async function submitInvite(job:InviteJob,cfg:InviteConfig,fetcher:typeof fetch=fetch,now=Date.now()){
 requireThat(cfg.enabled,503,'INVITE_DISABLED','Buyer invitations are not enabled.');
 requireThat(cfg.approvedSender===PROPOSED_SENDER&&cfg.approvedTemplate===INVITE_TEMPLATE_VERSION,503,'INVITE_APPROVAL','Sender and template approval required.');
 requireThat(cfg.approvedRecipients.includes(job.recipient),403,'INVITE_SCOPE','Recipient is outside the approved send scope.');
 requireThat(job.status==='PREPARED',409,'INVITE_FINISHED','Invite has already been processed.');
 // Resend retains deduplication keys for24h. Ambiguous sends older than23h need review, never blind retry.
 requireThat(now-Date.parse(job.createdAt)<23*3600_000&&now>=Date.parse(job.createdAt),409,'INVITE_REVIEW','This invitation needs delivery review before retrying.');
 requireThat(cfg.apiKey.startsWith('re_'),503,'INVITE_CONFIG','Sending is not configured.');
 const r=await fetcher('https://api.resend.com/emails',{method:'POST',headers:{Authorization:'Bearer '+cfg.apiKey,'Content-Type':'application/json','Idempotency-Key':job.id},body:JSON.stringify(job.payload),signal:AbortSignal.timeout(15000)});
 if(!r.ok)throw new Fault(r.status===429?429:502,'INVITE_PROVIDER','Invitation was not confirmed. Check provider delivery status before retrying.');
 const d=await r.json() as {id?:unknown};requireThat(typeof d.id==='string'&&d.id.length>0,502,'INVITE_PROVIDER','Provider acceptance was not confirmed.');
 return{...job,status:'SENT' as const,providerId:d.id}; // Accepted is not proof of inbox delivery.
}
