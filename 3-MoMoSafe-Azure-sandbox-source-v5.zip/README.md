# MoMoSafe sandbox MVP

Buyer-authorised handover workflow on Azure Functions, Cosmos DB and the MTN MoMo sandbox. No real money, currency conversion, insurance or licensing claim. Independent project, not an MTN-operated product.

Hosted sandbox: https://momosafe-053-sandbox.azurewebsites.net/

See [SANDBOX-STATUS.md](SANDBOX-STATUS.md) for verified results and unfinished work. The hosted landing page and anonymous HTTP boundaries are verified. Genuine hosted Google sign-in and full payment workflow testing are still in progress.

## One-login guided demo

An allowlisted Google owner can select Guided demo, then switch between seller, buyer and two demo operator seats. Records are isolated from pilot records. The banner and receipts state that one person plays all seats. This never counts as independent two-person dispute approval. Pilot mode still requires distinct real Google subjects for the two approvals.

## Workflow

Seller creates a ZAR or GHS product record. Buyer accepts, starting an MTN EUR sandbox collection. Authoritative status reads lock test funds. Seller creates a random one-use handover QR/token; buyer confirms after inspection to reserve the test seller payout. A 72-hour silence timeout reserves a test refund. A seller handover claim or participant dispute freezes the timeout for operator review. Two distinct matching operator approvals reserve release or refund.

Product currency is display/accounting denomination only. The numeric amount is sent as EUR canned test data, not converted to a real rand or cedi balance. Use fictional items and test data only.

## Build and tests

Node22+: `npm ci`, `npm test`, `npm run build`. 45 local tests cover the state machine, signed-session checks, sandbox adapter and HTTP boundaries. Deployment uses the resulting `dist/`, `azure-dist/`, production dependencies, `host.json` and `package.json`.

Cloud configuration: `MOMO_MODE=sandbox`, `APP_ORIGIN`, `GOOGLE_CLIENT_ID`, `SESSION_SECRET` (at least32 characters), `COSMOS_CONNECTION`, `AzureWebJobsStorage`, product-specific `MTN_COLLECTION_*` and `MTN_DISBURSEMENT_*` (`SUBSCRIPTION_KEY`, `API_USER`, `API_KEY`), `MTN_TEST_PAYER`, `MTN_TEST_PAYEE`. Operator emails use `ADMIN_EMAILS`; guided demo requires `GUIDED_DEMO_ENABLED=true` and `DEMO_OWNER_EMAILS`. Keep every secret in private deployment settings, never source.

## Structure

- `engine.ts`, `model.ts`, `store.ts`: state machine and storage contract.
- `sandbox-rail.ts`: MTN sandbox-only adapter, stable references, status reads.
- `azure.ts`, `cloud-http.ts`, `cosmos.ts`, `auth.ts`: Durable reconciliation, HTTP boundaries, transactional ledger and verified Google login.
- `cloud-web.tsx`: default hosted frontend.
- `*.test.ts`: unit and boundary tests.
- `LEGACY-MOCK.md`, `server.ts`, `web.tsx`, `preview.ts`: earlier local/device simulation. `npm run dev` starts that legacy local server, not the Azure backend. Build the device-only preview with `VITE_PREVIEW_MODE=device npm run build`.

## Not ready for real money

No production custody or MTN production onboarding. Runtime concurrency/restart, Durable replay/timers, backup restore, abuse/rate limits, retention/deletion and real independent operator tests remain unfinished. Camera scanning is not implemented; QR has copy/paste token entry. A50-deal sandbox guard is not complete rate limiting. Do not market this as a production payment service.
