import express from 'express';import {randomUUID,randomBytes} from 'node:crypto';import {Engine} from './engine.js';import {JsonStore} from './store.js';import {MockMoMo} from './momo.js';import {Fault,type Session} from './model.js';
if(process.env.NODE_ENV==='production'||process.env.MOMO_MODE&&process.env.MOMO_MODE!=='mock')throw new Error('Local mock server only. Production is disabled.');
const rail=new MockMoMo();const engine=new Engine(await new JsonStore(process.env.DATA_PATH??'.local/escrows.json').init(),rail);const sessions=new Map<string,Session>();
const app=express();app.disable('x-powered-by');app.use(express.json({limit:'8kb'}));
app.use((_req,res,next)=>{res.set('Cache-Control','no-store');res.set('X-Content-Type-Options','nosniff');next();});
app.get('/api/health',(_q,r)=>r.json({mode:'mock',rail:'in-process simulator',currency:'ZAR/GHS mock',money:'none'}));
// Identity selector is deliberate demo impersonation, never authentication.
app.post('/api/demo/session',(q,r)=>{const role=q.body.role;if(!['buyer','seller','admin'].includes(role))throw new Fault(400,'ROLE','Select a demo identity.');const adminId=role==='admin'?String(q.body.adminId):undefined;if(role==='admin'&&!['A','B'].includes(adminId!))throw new Fault(400,'ADMIN','Select demo admin A or B.');const token=randomBytes(32).toString('hex');const s:Session={role,id:role==='admin'?'demo-admin-'+adminId:'demo-'+role,adminId};sessions.set(token,s);r.json({token,session:s});});
app.use('/api',(q,r,next)=>{const session=sessions.get(q.headers.authorization?.replace(/^Bearer /,'')??'');if(!session)return next(new Fault(401,'SIGN_IN','Choose a demo identity first.'));r.locals.session=session;next();});
app.get('/api/escrows',async(_q,r)=>r.json(await engine.list(r.locals.session)));
app.post('/api/escrows',async(q,r)=>r.status(201).json(await engine.create(q.body,r.locals.session,String(q.headers['idempotency-key']??''))));
app.get('/api/escrows/:id',async(q,r)=>r.json(await engine.get(String(q.params.id),r.locals.session)));
app.get('/api/escrows/:id/qr',async(q,r)=>r.json(await engine.qr(String(q.params.id),r.locals.session)));
app.post('/api/escrows/:id/:action',async(q,r)=>{const id=String(q.params.id);if(q.params.action==='simulate'){const e=await engine.get(id,r.locals.session);const op=e.ops.find(o=>o.status==='PENDING');if(!op)throw new Fault(409,'NO_PENDING','No pending operation.');if(!['SUCCESSFUL','FAILED','PENDING'].includes(q.body.status))throw new Fault(400,'STATUS','Invalid simulation result.');rail.settle(op.ref,q.body.status);await engine.reconcile(id);return r.json(await engine.get(id,r.locals.session));}r.json(await engine.command(id,String(q.params.action),q.body,r.locals.session));});
app.post('/api/momo/callback',async(_q,r)=>{await engine.reconcile();r.json({accepted:true,note:'Body ignored. Read mock rail status.'});});
app.use((e:any,_q:express.Request,r:express.Response,_n:express.NextFunction)=>{const known=e instanceof Fault;r.status(known?e.status:e.name==='ZodError'?400:500).json({code:known?e.code:'INVALID_REQUEST',message:known?e.message:'Request could not be processed.',requestId:randomUUID()});});
app.listen(7071,'127.0.0.1',()=>console.log('MoMoSafe mock API on http://127.0.0.1:7071 (no real money)'));
setInterval(()=>engine.reconcile().catch(()=>console.error('Reconciliation failed; retrying next interval.')),1000).unref();
