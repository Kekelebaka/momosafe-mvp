import {createRemoteJWKSet,jwtVerify,SignJWT} from 'jose';
import {Fault,requireThat,type Session} from './model.js';
const googleKeys=createRemoteJWKSet(new URL('https://www.googleapis.com/oauth2/v3/certs'));
export type Identity={id:string;email:string;name:string};
export async function verifyGoogle(token:string,clientId:string):Promise<Identity>{
 requireThat(clientId,503,'AUTH_NOT_CONFIGURED','Google sign-in is not configured.');
 const {payload}=await jwtVerify(token,googleKeys,{issuer:['https://accounts.google.com','accounts.google.com'],audience:clientId,algorithms:['RS256'],maxTokenAge:'10m'});
 requireThat(typeof payload.sub==='string'&&typeof payload.email==='string'&&payload.email_verified===true,401,'IDENTITY','Use a verified Google email address.');
 return{id:'google:'+payload.sub,email:payload.email.toLowerCase(),name:typeof payload.name==='string'?payload.name.slice(0,100):''};
}
function key(secret:string){requireThat(secret.length>=32,503,'AUTH_NOT_CONFIGURED','Session signing is not configured.');return new TextEncoder().encode(secret);}
export async function issueSession(identity:Identity,secret:string){return new SignJWT({email:identity.email}).setProtectedHeader({alg:'HS256'}).setSubject(identity.id).setIssuer('momosafe-sandbox').setAudience('momosafe-api').setIssuedAt().setExpirationTime('1h').setJti(crypto.randomUUID()).sign(key(secret));}
export async function verifySession(token:string,secret:string):Promise<Identity>{try{const {payload}=await jwtVerify(token,key(secret),{issuer:'momosafe-sandbox',audience:'momosafe-api',algorithms:['HS256']});requireThat(typeof payload.sub==='string'&&payload.sub.startsWith('google:')&&typeof payload.email==='string',401,'SESSION','Sign in again.');return{id:payload.sub,email:payload.email,name:''};}catch(e){if(e instanceof Fault&&e.status===503)throw e;throw new Fault(401,'SESSION','Sign in again.');}}
export function roleSession(identity:Identity,role:unknown,adminEmails:string[]):Session{if(role==='admin'){requireThat(adminEmails.includes(identity.email),403,'ADMIN_ONLY','Operator access is not granted.');return{id:identity.id,role:'admin',adminId:identity.id};}requireThat(role==='seller'||role==='buyer',400,'ROLE','Choose buyer or seller.');return{id:identity.id,role};}
