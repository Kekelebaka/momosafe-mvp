import {Engine} from './engine';import {MockMoMo} from './momo';import type {Escrow,Session} from './model';
const enabled=import.meta.env.VITE_PREVIEW_MODE==='device';
const rail=new MockMoMo();
const storageKey='momosafe-device-preview-v1';
const store={async get(id:string){return(await this.list()).find(e=>e.id===id);},async list():Promise<Escrow[]>{return JSON.parse(localStorage.getItem(storageKey)||'[]');},async save(e:Escrow,expected:number){const rows=await this.list();if((rows.find(r=>r.id===e.id)?.version??0)!==expected)throw new Error('CONFLICT');localStorage.setItem(storageKey,JSON.stringify([...rows.filter(r=>r.id!==e.id),e]));}};
const engine=new Engine(store,rail);
const identities=new Map<string,Session>();
if(enabled)setInterval(()=>engine.reconcile().catch(()=>{}),1000);
export const transport:typeof fetch=async(input,init)=>{
 if(!enabled)return fetch(input,init);
 try{const path=String(input).replace(/^\/api/,'');const method=init?.method||'GET';const body=init?.body?JSON.parse(String(init.body)):{};const headers=new Headers(init?.headers);let result:unknown;
 if(path==='/demo/session'){if(!['seller','buyer','admin'].includes(body.role))throw new Error('Choose a demo identity.');if(body.role==='admin'&&!['A','B'].includes(body.adminId))throw new Error('Choose demo admin A or B.');const token=crypto.randomUUID();const session:Session={id:body.role==='admin'?'demo-admin-'+body.adminId:'demo-'+body.role,role:body.role,adminId:body.adminId};identities.set(token,session);sessionStorage.setItem('preview-identity-'+token,JSON.stringify(session));result={token,session};}
 else{const token=headers.get('Authorization')?.replace('Bearer ','')||'';const s=identities.get(token)||JSON.parse(sessionStorage.getItem('preview-identity-'+token)||'null');if(!s)return Response.json({message:'Choose a demo identity first.'},{status:401});if(path==='/escrows')result=method==='POST'?await engine.create(body,s,headers.get('Idempotency-Key')||''):await engine.list(s);
 else{const parts=path.split('/').filter(Boolean);const id=parts[1],action=parts[2];if(!action)result=await engine.get(id,s);else if(action==='qr')result=await engine.qr(id,s);else if(action==='simulate'){const e=await engine.get(id,s);const op=e.ops.find(o=>o.status==='PENDING');if(!op)throw new Error('No pending operation.');if(!['PENDING','SUCCESSFUL','FAILED'].includes(body.status))throw new Error('Invalid result.');rail.settle(op.ref,body.status);await engine.reconcile(id);result=await engine.get(id,s);}else result=await engine.command(id,action,body,s);}}
 return Response.json(result);
 }catch(e:any){return Response.json({message:e.message||'Request failed.'},{status:e.status||400});}
};
